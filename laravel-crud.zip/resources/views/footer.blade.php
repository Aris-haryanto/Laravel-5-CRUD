<footer class="footer">
    <div class="container">
        <p class="muted credit">Laravel 5 - Example CRUD By <a href="https://id.linkedin.com/in/aris-haryanto-0466b2a5">Aris Haryanto</a></p>
    </div>
</footer>    
    <script type="text/javascript" src="{{ url('assets/js/jquery-2.1.3.min.js') }}"></script>
	<script type="text/javascript" src="{{ url('assets/js/bootstrap.min.js') }}"></script>
	<script type="text/javascript" src="{{ url('assets/js/jquery.dataTables.js') }}"></script>
    <script type="text/javascript" src="{{ url('assets/js/main.js') }}"></script>
</body>

</html>
