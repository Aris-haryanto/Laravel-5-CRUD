@include('header')
<div class="container">
@yield('content')
</div>
@include('footer')